#include <SFML/Graphics.hpp>
#include <SFML/System/Sleep.hpp>
#include <iostream>
#include <vector>

using namespace std;

char checkWinner(const vector<vector<char> >& board) {
    for (int i = 0; i < 3; ++i) {
        if (board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != ' ')
            return board[i][0];

        if (board[0][i] == board[1][i] && board[1][i] == board[2][i] && board[0][i] != ' ')
            return board[0][i];
    }

    if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != ' ')
        return board[0][0];

    if (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != ' ')
        return board[0][2];

    return ' ';
}

bool isBoardFull(const vector<vector<char> >& board) {
    for (const auto& row : board) {
        for (char cell : row) {
            if (cell == ' ')
                return false;
        }
    }
    return true;
}

bool isValidMove(const vector<vector<char> >& board, int row, int col) {
    return row >= 0 && row < 3 && col >= 0 && col < 3 && board[row][col] == ' ';
}

void resetBoard(vector<vector<char> >& board) {
    for (auto& row : board) {
        for (char& cell : row) {
            cell = ' ';
        }
    }
}

// Implement the minimax algorithm to find the best move for AI
int minimax(vector<vector<char> >& board, int depth, bool isMaximizing) {
    char winner = checkWinner(board);
    if (winner == 'O') {
        return 1;
    } else if (winner == 'X') {
        return -1;
    } else if (isBoardFull(board)) {
        return 0;
    }

    int bestScore = isMaximizing ? -1000 : 1000;

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            if (board[i][j] == ' ') {
                if (isMaximizing) {
                    board[i][j] = 'O';
                    int score = minimax(board, depth + 1, false);
                    board[i][j] = ' ';
                    bestScore = max(bestScore, score);
                } else {
                    board[i][j] = 'X';
                    int score = minimax(board, depth + 1, true);
                    board[i][j] = ' ';
                    bestScore = min(bestScore, score);
                }
            }
        }
    }

    return bestScore;
}

void makeAIMove(vector<vector<char> >& board) {
    int bestScore = -1000;
    pair<int, int> bestMove = make_pair(-1, -1);

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            if (board[i][j] == ' ') {
                board[i][j] = 'O';
                int score = minimax(board, 0, false);
                board[i][j] = ' ';

                if (score > bestScore) {
                    bestScore = score;
                    bestMove = make_pair(i, j);
                }
            }
        }
    }

    board[bestMove.first][bestMove.second] = 'O';
}
void drawBoard(sf::RenderWindow& window, const vector<vector<char> >& board) {
    // Load font
    sf::Font font;
    if (!font.loadFromFile("/System/Library/Fonts/Supplemental/Arial.ttf")) {
        cout << "Error loading font!" << endl;
        return;
    }

    for (int i = 1; i < 3; ++i) {
        sf::RectangleShape line(sf::Vector2f(5, 450));
        line.setFillColor(sf::Color::Black);
        line.setPosition(i * 150, 0);
        window.draw(line);

        line.setPosition(0, i * 150);
        line.setRotation(90);
        window.draw(line);
        line.setRotation(0);
    }

    sf::RectangleShape horizontalLine(sf::Vector2f(450, 5));
    horizontalLine.setFillColor(sf::Color::Black);
    horizontalLine.setPosition(0, 150);
    window.draw(horizontalLine);

    horizontalLine.setPosition(0, 300);
    window.draw(horizontalLine);

    sf::RectangleShape verticalLine(sf::Vector2f(5, 450));
    verticalLine.setFillColor(sf::Color::Black);
    verticalLine.setPosition(150, 0);
    window.draw(verticalLine);

    verticalLine.setPosition(300, 0);
    window.draw(verticalLine);

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            sf::Text text;
            text.setFont(font);
            text.setCharacterSize(50);
            text.setPosition(j * 150 + 45, i * 150 + 45);

            if (board[i][j] == 'X') {
                text.setString("X");
                window.draw(text);
            } else if (board[i][j] == 'O') {
                text.setString("O");
                window.draw(text);
            }
        }
    }
}

int main() {
    sf::RenderWindow window(sf::VideoMode(450, 550), "Tic Tac Toe", sf::Style::Titlebar | sf::Style::Close);

    // Initialize the game board
    char currentPlayer = 'X';
    vector<vector<char> > board(3, vector<char>(3, ' '));

    bool userFirstMove = true; // Track if the user wants to make the first move
    bool gameOver = false; // Track if the game is over

    // Create buttons
    sf::RectangleShape newGameButton(sf::Vector2f(150, 50));
    newGameButton.setPosition(0, 450);
    newGameButton.setFillColor(sf::Color::Green);

    sf::RectangleShape resetButton(sf::Vector2f(150, 50));
    resetButton.setPosition(150, 450);
    resetButton.setFillColor(sf::Color::Blue);

    sf::RectangleShape quitButton(sf::Vector2f(150, 50));
    quitButton.setPosition(300, 450);
    quitButton.setFillColor(sf::Color::Red);

    // Load font
    sf::Font font;
    if (!font.loadFromFile("/System/Library/Fonts/Supplemental/Arial.ttf")) {
        cout << "Error loading font!" << endl;
        return 1;
    }

    // Game outcome message
    sf::Text message;
    message.setFont(font);
    message.setCharacterSize(30);
    message.setPosition(50, 500);
    message.setFillColor(sf::Color::White);

    while (window.isOpen()) {
        sf::Event event;

        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }

            if (event.type == sf::Event::MouseButtonPressed && !gameOver) {
                sf::Vector2i mousePosition = sf::Mouse::getPosition(window);
                int row = mousePosition.y / 150;
                int col = mousePosition.x / 150;

                // Check if the move is valid and update the board
                if (isValidMove(board, row, col) && currentPlayer == 'X') {
                    board[row][col] = 'X';
                    char winner = checkWinner(board);
                    if (winner != ' ') {
                        message.setString("Player " + string(1, winner) + " wins!");
                        gameOver = true;
                    } else if (isBoardFull(board)) {
                        message.setString("It's a tie!");
                        gameOver = true;
                    } else {
                        currentPlayer = 'O'; // Switch to AI's turn
                    }
                }
            }

            // Handle button clicks
            if (event.type == sf::Event::MouseButtonPressed && gameOver) {
                sf::Vector2i mousePosition = sf::Mouse::getPosition(window);

                // New Game button
                if (newGameButton.getGlobalBounds().contains(mousePosition.x, mousePosition.y)) {
                    resetBoard(board);
                    gameOver = false;
                    currentPlayer = userFirstMove ? 'X' : 'O';
                    message.setString("");
                }

                // Reset button
                if (resetButton.getGlobalBounds().contains(mousePosition.x, mousePosition.y)) {
                    resetBoard(board);
                    currentPlayer = userFirstMove ? 'X' : 'O';
                    message.setString("");
                }

                // Quit button
                if (quitButton.getGlobalBounds().contains(mousePosition.x, mousePosition.y)) {
                    window.close();
                }
            }
        }

        // AI's turn
        if (currentPlayer == 'O' && !gameOver) {
            makeAIMove(board);
            char winner = checkWinner(board);
            if (winner != ' ') {
                message.setString("AI wins!");
                gameOver = true;
            } else if (isBoardFull(board)) {
                message.setString("It's a tie!");
                gameOver = true;
            } else {
                currentPlayer = 'X'; // Switch to player's turn
            }
        }

        // Clear the window
        window.clear();

        // Draw the board
        drawBoard(window, board);

        // Draw buttons
        window.draw(newGameButton);
        window.draw(resetButton);
        window.draw(quitButton);

        // Draw button labels
        sf::Text newGameLabel;
        newGameLabel.setFont(font);
        newGameLabel.setCharacterSize(20);
        newGameLabel.setPosition(25, 465);
        newGameLabel.setFillColor(sf::Color::Black);
        newGameLabel.setString("New Game");
        window.draw(newGameLabel);

        sf::Text resetLabel;
        resetLabel.setFont(font);
        resetLabel.setCharacterSize(20);
        resetLabel.setPosition(175, 465);
        resetLabel.setFillColor(sf::Color::Black);
        resetLabel.setString("Reset");
        window.draw(resetLabel);

        sf::Text quitLabel;
        quitLabel.setFont(font);
        quitLabel.setCharacterSize(20);
        quitLabel.setPosition(340, 465);
        quitLabel.setFillColor(sf::Color::Black);
        quitLabel.setString("Quit");
        window.draw(quitLabel);

        // Draw message
        window.draw(message);

        // Display the window
        window.display();
        sf::sleep(sf::milliseconds(100));
    }

    return 0;
}
